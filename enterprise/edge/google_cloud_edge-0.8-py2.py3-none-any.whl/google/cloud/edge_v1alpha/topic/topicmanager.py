# Copyright 2018, Google LLC All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import absolute_import
from __future__ import print_function

import os
import re

_TOPIC_DELIM = ','
_TOPIC_INPUT = True
_TOPIC_OUTPUT = False

# These environment variables are used for getting I/O topics from the runtime.
_ENV_INPUT_TOPICS = 'X_GOOGLE_INPUT_TOPICS'
_ENV_OUTPUT_TOPICS = 'X_GOOGLE_OUTPUT_TOPICS'


def get_flattened_topic_from_env(is_input):
    """Returns the flattened topic string from the environment variables.

    Args:
        is_input: Whether to get the flattened topics for input topics, or
            output topics. Use either _TOPIC_INPUT or _TOPIC_OUTPUT constant.

    Returns:
        The flattened topic string, which is expected to be in
        "[NAME0:]TOPIC0,[NAME1:]TOPIC1,..." format.
    """
    key = _ENV_INPUT_TOPICS if is_input else _ENV_OUTPUT_TOPICS
    return os.environ[key] if key in os.environ else None


def get_topic_count(flattened_topics):
    """Returns the topic count in the given flattened topic string.

    Args:
        flattened_topics: Flattened topic string, which is expected to be in
            "[NAME0:]TOPIC0,[NAME1:]TOPIC1,..." format.

    Returns:
        The number of topics found in the flattened topic string.

    Raises:
        ValueError: If the given flattened_topics value is None.
    """
    if flattened_topics is None:
        raise ValueError('I/O topics are not properly set.')

    return len(flattened_topics.split(_TOPIC_DELIM))


def build_topic_dict(flattened_topics):
    """Returns the processed topic dictionary from the flattened topic string.

    Args:
        flattened_topics: Flattened topic string, which is expected to be in
            "[NAME0:]TOPIC0,[NAME1:]TOPIC1,..." format.

    Returns:
        The processed topic dictionary whose keys are the index values (either
        zero-based numbers or strings) and the values are the topics associated
        with those index values.

    Raises:
        ValueError: If the given flattened_topics value is None.
    """
    if flattened_topics is None:
        raise ValueError('I/O topics are not properly set.')

    topic_dict = {}
    topic_infos = flattened_topics.split(_TOPIC_DELIM)

    for i, topic_info in enumerate(topic_infos):
        topic_info = topic_infos[i]
        match = re.match(r'^(?:([^:]+):)?([^:]+)$', topic_info)
        if not match:
            raise ValueError('Invalid format in topic info: ' + topic_info)

        name = match.group(1)
        topic = match.group(2)

        topic_dict[i] = topic
        if name:
            topic_dict[name] = topic

    return topic_dict


class TopicManager(object):
    """TopicManager provides utility functions for accessing I/O topics."""

    def __init__(self, flattened_input_topics, flattened_output_topics):
        """Creates a new TopicManager instance.

        Args:
            flattened_input_topics: The flattened input topic string from the
                environment variables.
            flattened_output_topics: The flattened output topic string from the
                environment variables.

        Raises:
            ValueError: If the I/O topics are not properly set.
        """
        self._input_topic_count = get_topic_count(flattened_input_topics)
        self._input_topic_dict = build_topic_dict(flattened_input_topics)
        self._output_topic_count = get_topic_count(flattened_output_topics)
        self._output_topic_dict = build_topic_dict(flattened_output_topics)

    def get_input_topic_count(self):
        """Returns the number of input topics, including the default topic.

        Returns:
            The number of input topics.
        """
        return self._input_topic_count

    def get_input_topic(self, index=0):
        """Returns the specified input topic.

        Args:
            index: A zero-based index value for the input topic, or a string
                name associated with the input topic. If not specified, the
                first input topic (default topic) is returned.

        Returns:
            The specified input topic, or None if the specified input topic is
            not found.
        """
        if index in self._input_topic_dict:
            return self._input_topic_dict[index]

        return None

    def get_output_topic_count(self):
        """Returns the number of output topics, including the default topic.

        Returns:
            The number of output topics.
        """
        return self._output_topic_count

    def get_output_topic(self, index=0):
        """Returns the specified output topic.

        Args:
            index: A zero-based index value for the output topic, or a string
                name associated with the output topic. If not specified, the
                first output topic (default topic) is returned.

        Returns:
            The specified output topic, or None if the specified output topic
            is not found.
        """
        if index in self._output_topic_dict:
            return self._output_topic_dict[index]

        return None


# Lazily instantiate the default topic manager to prevent crashing the entire
# application when the topic manager is not actually used.
default_topic_manager = None


def _create_default_topic_manager():
    global default_topic_manager
    if not default_topic_manager:
        default_topic_manager = TopicManager(
            get_flattened_topic_from_env(_TOPIC_INPUT),
            get_flattened_topic_from_env(_TOPIC_OUTPUT))


def get_input_topic(index=0):
    """Returns the specified input topic.

    Args:
        index: A zero-based index value for the input topic, or a string
            name associated with the input topic. If not specified, the
            first input topic (default topic) is returned.

    Returns:
        The specified input topic, or None if the specified input topic is
        not found.
    """
    _create_default_topic_manager()
    return default_topic_manager.get_input_topic(index)


def get_input_topic_count():
    """Returns the number of input topics, including the default topic.

    Returns:
        The number of input topics.
    """
    _create_default_topic_manager()
    return default_topic_manager.get_input_topic_count()


def get_output_topic(index=0):
    """Returns the specified output topic.

    Args:
        index: A zero-based index value for the output topic, or a string
            name associated with the output topic. If not specified, the
            first output topic (default topic) is returned.

    Returns:
        The specified output topic, or None if the specified output topic is
        not found.
    """
    _create_default_topic_manager()
    return default_topic_manager.get_output_topic(index)


def get_output_topic_count():
    """Returns the number of output topics, including the default topic.

    Returns:
        The number of output topics.
    """
    _create_default_topic_manager()
    return default_topic_manager.get_output_topic_count()
