# Copyright 2018, Google LLC All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#         http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import absolute_import

import os
import uuid
import json


# Read environments to find the location of Edge Pub/Sub server.
_ENV_BROKER_HOSTNAME = 'X_GOOGLE_BROKER_HOSTNAME'
_ENV_BROKER_PORT = 'X_GOOGLE_BROKER_PORT'

# Read environment to find the location of mqtt client credentials.
_ENV_MQTT_CLIENT_CREDENTIALS = 'X_GOOGLE_MQTT_CLIENT_CREDENTIALS'


def _gen_mqtt_client_id(prefix='edge_pubsub_v1alpha_python_client_'):
    """Generates MQTT client identifier.

    Args:
        prefix (string): The prefix for MQTT client Id

    Returns:
        A string.
    """
    return prefix + str(uuid.uuid4())


def _read_credentials(mqtt_client_credentials):
    """Reads the MQTT client credentials from MQTT client credentials file.

    It sets up MQTT client credentials by reading MQTT client credentials
    file.

    Args:
        mqtt_client_credentials (string): The path of MQTT client
            credentials file.

    Returns:
            The MQTT client credentials.
    """
    if os.path.exists(mqtt_client_credentials):
        try:
            with open(mqtt_client_credentials) as f:
                credentials = json.load(f)
                mqtt_client_id = _gen_mqtt_client_id(
                    credentials['clientIdPrefix'])
                mqtt_username = credentials['username']
                mqtt_password = credentials['password']
        except (ValueError, KeyError):
            raise ValueError("MQTT client credentials file doesn't "
                             "have valid format.")
    else:
        raise IOError("MQTT client credentials doesn't exist.")

    return mqtt_client_id, mqtt_username, mqtt_password


def gen_credentials():
    """Generates the MQTT client credentials.

    It creates MQTT client credentials for connecting
    to the Edge Pub/Sub server. The credentials of each client should be
    different so it should be called whenever a new client is created.

    Returns:
            The MQTT client credentials.
    """

    if _ENV_MQTT_CLIENT_CREDENTIALS in os.environ:
        return _read_credentials(
            os.getenv(_ENV_MQTT_CLIENT_CREDENTIALS))

    return _gen_mqtt_client_id(), None, None


def get_broker_params():
    """Returns the MQTT broker information.

    It returns the MQTT broker information for connecting
    to the Edge Pub/Sub server.

    Returns:
            The MQTT broker information.
    """
    host = os.getenv(_ENV_BROKER_HOSTNAME, 'localhost')
    port = int(os.getenv(_ENV_BROKER_PORT, '1883'))

    return host, port
