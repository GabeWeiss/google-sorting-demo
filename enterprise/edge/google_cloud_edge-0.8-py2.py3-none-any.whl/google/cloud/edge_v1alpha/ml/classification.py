# Copyright 2018, Google LLC All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import absolute_import

import base64

from google.cloud.edge_v1alpha.ml.proto import edge_ml_pb2
from google.cloud.edge_v1alpha.ml.proto import classification_pb2
from google.cloud.edge_v1alpha.ml.proto import example_pb2
from google.cloud.edge_v1alpha.ml.proto import feature_pb2
from google.cloud.edge_v1alpha.ml.proto import model_pb2
from google.cloud.edge_v1alpha.ml.proto import input_pb2

"""Sorted parameters to sort the classification results in ascending.

Example:
    >> from google.cloud.edge_v1alpha import ml
    >>
    >>
    >> response = ml.ClassificationResponse(payload)
    >> sorted(response.classifications[0], **ml.by_score_asc)
"""
by_score_asc = {'key': lambda x: x.score, 'reverse': False}


"""Sorted parameters to sort the classification results in descending.

Example:
    >> from google.cloud.edge_v1alpha import ml
    >>
    >>
    >> response = ml.ClassificationResponse(payload)
    >> sorted(response.classifications[0], **ml.by_score_desc)
"""
by_score_desc = {'key': lambda x: x.score, 'reverse': True}


class Class(object):
    """A class for storing a feature label and its score.

    This class represents a pair of a feature and its score from the
    classification result.
    """

    def __init__(self, label, score):
        """Constructor.

        Args:
            label (str): Feature label.
            score (float): Classification score.
        """
        self._label = label
        self._score = score

    @property
    def label(self):
        """Returns the feature label.

        Returns:
            Feature label (str).
        """
        return self._label

    @property
    def score(self):
        """Returns the score of the feature.

        Returns:
            Classification score (float).
        """
        return self._score

    def __lt__(self, other):
        # Sort by the score field.
        return self._score < other._score

    def __str__(self):
        """Returns a formatted string of the feature result.

        Returns:
            String (str).
        """
        return 'Class(label="%s", score=%f)' % (self._label, self._score)


class Request(object):
    """A classification request for Edge ML.

    This object is used to generate an ML classification request.
    By combining the provided model name, example data and user context,
    it can produce the corresponding byte array to be fired as a payload
    at the input topic of the target EdgeML model.

    Example:
        >> from paho.mqtt import client as mqtt_client
        >> from google.cloud.edge_v1alpha import pubsub
        >> from google.cloud.edge_v1alpha import ml
        >>
        >> client_id, username, password = pubsub.gen_credentials()
        >> client = mqtt_client.Client(client_id)
        >> client.username_pw_set(username, password)
        >> client.connect(*pubsub.get_broker_params())
        >> client.loop_start()
        >>
        >> //... acquire image bytes into list of bytes.
        >> bytes_list = ...  # For example, [b'red', b'blue', b'green']
        >> request = ml.ClassificationRequest('model_name')
        >> request.add_example('input', bytes_list)
        >> pub_info = client.publish('/mlservice/example/input',
        >>                            request.to_bytes())
        >> pub_info.wait_for_publish()
    """

    def __init__(self, model_name):
        """Instantiate the Request class.

        Args:
            model_name (str): The model name of Edge ML to classify.
        """
        # Create an edge classification request object with the provided model
        # name.
        self._model_name = model_name
        self._user_context = b''
        self._feature = {}

    def add_example(self, name, bytes_list):
        """Add an example to the classification request.

        Multiple example data can be added via calling this method multiple
        times.

        Args:
            name (str): Name of input tensor to load.
            bytes_list (list[bytes]): Example data to be classified
        """
        self._feature[name] = bytes_list

    def set_user_context(self, user_context):
        """Sets the new user context to the classification request.

        The user context will be utilized for retrieving the corresponding
        result in the output topic.

        Args:
            user_context (bytes): User context to identify the request.
        """
        self._user_context = user_context

    def to_bytes(self):
        """Returns the serialized data as a byte array to classify.

        Returns:
            Serialized data in bytes.
        """
        request = edge_ml_pb2.EdgeMlRequest(
            classification_request=classification_pb2.ClassificationRequest(
                model_spec=model_pb2.ModelSpec(name=self._model_name),
                input=input_pb2.Input(
                    example_list=input_pb2.ExampleList(examples=[
                        example_pb2.Example(features=feature_pb2.Features(
                            feature={}))]))),
            user_context=self._user_context)
        example_list = request.classification_request.input.example_list
        feature = example_list.examples[0].features.feature
        for name, bytes_list in self._feature.items():
            feature[name].CopyFrom(feature_pb2.Feature(
                bytes_list=feature_pb2.BytesList(value=bytes_list)))
        return request.SerializeToString()

    def __str__(self):
        """Returns a formatted string of the Edge ML request.

        Returns:
            String (str).
        """
        return self.to_bytes().decode('utf-8')


class Response(object):
    """A classification response for Edge ML.

    This object is used to parse an ML classification.
    To identify the original classification request, you should set the user
    context when generating a request and then retrieve the response that has
    the same user context. A classfication result has the list of scores of
    features. You can find them by using it as well.

    Example:
        >> from paho.mqtt import client as mqtt_client
        >> from google.cloud.edge_v1alpha import pubsub
        >> from google.cloud.edge_v1alpha import ml
        >>
        >>
        >> client_id, username, password = pubsub.gen_credentials()
        >> client = mqtt_client.Client(client_id)
        >> client.username_pw_set(username, password)
        >>
        >> def on_message(client, userdata, msg):
        >>     if topic == '/mlservice/example/output':
        >>         response = ml.ClassificationResponse(msg.payload)
        >>         for item in response.classifications[0].classes:
        >>             print('{}: {}'.format(item.label, str(item.score)))
        >>         top_class = sorted(
        >>             response.classifications[0], **ml.by_score_desc)[0]
        >>         print('Predicted class is {}'.format(top_class.label))
        >>         client.disconnect()
        >>
        >>
        >> client.on_message = on_message
        >>
        >> client.connect(*pubsub.get_broker_params())
        >> client.subscribe('/mlservice/example/output')
        >> client.loop_forever()
    """

    def __init__(self, raw_bytes):
        """Constructors a classification response.

        Args:
            raw_bytes (bytes): Raw byte array from the payload of the ML output
                topic.
        """
        self._resp = edge_ml_pb2.EdgeMlResponse()
        self._resp.ParseFromString(raw_bytes)

    @property
    def model_name(self):
        """Returns the model name of the classification.

        Returns:
            Model name string.
        """
        return self._resp.classification_response.model_spec.name

    @property
    def user_context(self):
        """Returns the user context of the classification result.

        This value is the same with the user context value of the corresponding
        classification request.

        Returns:
            User context (bytes).
        """
        return self._resp.user_context

    def _create_class_array(self, classes):
        return [Class(item.label, item.score) for item in classes]

    @property
    def classifications(self):
        """Returns list of classification results as array.

        Each index contains a classification result in a form of the list of
        :class:`~google.cloud.edge_v1alpha.ml.Class` instances.

        Returns:
            List of list of :class:`~google.cloud.edge_v1alpha.ml.Class`
                instances.
        """
        items = self._resp.classification_response.result.classifications
        return [self._create_class_array(item.classes) for item in items]

    def __str__(self):
        """Returns a formatted string of the Edge ML response.

        Returns:
            String (str).
        """
        return ('ClassificationResponse(model_name=%s, classifications=%s, '
                'user_context= %s)'
                % (
                    self.model_name,
                    self.classifications,
                    base64.b64encode(self.user_context)))
