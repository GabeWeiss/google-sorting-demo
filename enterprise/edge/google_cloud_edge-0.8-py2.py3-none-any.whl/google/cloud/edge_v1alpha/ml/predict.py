# Copyright 2019, Google LLC All rights reserved.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

from __future__ import absolute_import

import base64

from google.cloud.edge_v1alpha.ml.proto import edge_ml_pb2
from google.cloud.edge_v1alpha.ml.proto import predict_pb2
from google.cloud.edge_v1alpha.ml.proto import model_pb2
from google.cloud.edge_v1alpha.ml.proto import tensor_pb2


class Request(object):
    """A predict request for Edge ML.

    This object is used to generate an ML predict request.
    By combining the provided model name, example data and user context,
    it can produce the corresponding byte array to be fired as a payload
    at the input topic of the target EdgeML model.

    Example:
        >> from paho.mqtt import client as mqtt_client
        >> from google.cloud.edge_v1alpha import pubsub
        >> from google.cloud.edge_v1alpha import ml
        >>
        >> client_id, username, password = pubsub.gen_credentials()
        >> client = mqtt_client.Client(client_id)
        >> client.username_pw_set(username, password)
        >> client.connect(*pubsub.get_broker_params())
        >> client.loop_start()
        >>
        >> //... acquire image bytes into list of bytes.
        >> img_as_bytes = ...  # For example, np.asarray(img).tobytes()
        >> request = ml.PredictRequest('model_name')
        >> request.add_example('input', img_as_bytes)
        >> pub_info = client.publish('/mlservice/example/input',
        >>                           request.to_bytes())
        >> pub_info.wait_for_publish()
    """

    def __init__(self, model_name):
        """Instantiate the Request class.

        Args:
            model_name (str): The model name of Edge ML to predict.
        """
        # Create an edge predict request object with the provided model
        # name.
        self._model_name = model_name
        self._user_context = b''
        self._feature = {}

    def add_example(self, name, byte_data):
        """Add an example to the predict request.

        Multiple example data can be added via calling this method multiple
        times.

        Args:
            name (str): Name of input tensor to load.
            byte_data (bytes): Example data to be predicted.
        """
        self._feature[name] = byte_data

    def set_user_context(self, user_context):
        """Sets the new user context to the predict request.

        The user context will be utilized for retrieving the corresponding
        result in the output topic.

        Args:
            user_context (bytes): User context to identify the request.
        """
        self._user_context = user_context

    def to_bytes(self):
        """Returns the serialized data as a byte array to predict.

        Returns:
            Serialized data in bytes.
        """
        request = edge_ml_pb2.EdgeMlRequest(
            predict_request=predict_pb2.PredictRequest(
                model_spec=model_pb2.ModelSpec(name=self._model_name),
            ),
            user_context=self._user_context)
        for name, byte_data in self._feature.items():
            tensor = tensor_pb2.TensorProto()
            tensor.tensor_content = byte_data
            request.predict_request.inputs[name].CopyFrom(tensor)
        return request.SerializeToString()

    def __str__(self):
        """Returns a formatted string of the Edge ML request.

        Returns:
            String (str).
        """
        return self.to_bytes().decode('utf-8')


class Response(object):
    """A predict response for Edge ML.

    This object is used to parse an ML predict.
    To identify the original predict request, you should set the user
    context when generating a request and then retrieve the response that has
    the same user context.

    Example:
        >> from paho.mqtt import client as mqtt_client
        >> from google.cloud.edge_v1alpha import pubsub
        >> from google.cloud.edge_v1alpha import ml
        >>
        >> client_id, username, password = pubsub.gen_credentials()
        >> client = mqtt_client.Client(client_id)
        >> client.username_pw_set(username, password)
        >>
        >>
        >> def on_message(client, topic, msg):
        >>     if topic == '/mlservice/example/output':
        >>         response = ml.PredictResponse(msg.payload)
        >>         for name, output in response.outputs.items():
        >>             raw_float_values = output.float_val
        >>             max_class = raw_float_values.index(
        >>                 max(raw_float_values))
        >>             print('{}, {}'.format(name, max_class))
        >>         client.disconnect()
        >>
        >>
        >> client.on_message = on_message
        >>
        >> client.connect(*pubsub.get_broker_params())
        >> client.subscribe('/mlservice/example/output')
        >>
        >> client.loop_forever()
    """

    def __init__(self, raw_bytes):
        """Constructors a predict response.

        Args:
            raw_bytes (bytes): Raw byte array from the payload of the ML output
                topic.
        """
        self._resp = edge_ml_pb2.EdgeMlResponse()
        self._resp.ParseFromString(raw_bytes)

    @property
    def model_name(self):
        """Returns the model name of the predict.

        Returns:
            Model name string.
        """
        return self._resp.predict_response.model_spec.name

    @property
    def user_context(self):
        """Returns the user context of the predict result.

        This value is the same with the user context value of the corresponding
        predict request.

        Returns:
            User context (bytes).
        """
        return self._resp.user_context

    @property
    def outputs(self):
        """Returns map of results.

        Returns:
             Dictionary of :class:`google.cloud.edge_v1alpha.ml.TensorProto`
                 keyed by strings containing output tensor names.
        """
        return self._resp.predict_response.outputs

    def __str__(self):
        """Returns a formatted string of the Edge ML response.

        Returns:
            String (str).
        """
        return ('PredictResponse(model_name=%s, predicts=%s, '
                'user_context= %s)'
                % (
                    self.model_name,
                    self.outputs,
                    base64.b64encode(self.user_context)))
